# Assistente NUCA — Cloudflare Pages + Groq

Chatbot Flask com interface com identidade visual do projeto e leitura dos **mesmos JSONs públicos** utilizados pelo painel NUCAs/UNICEF. Não consulta diretamente o Supabase e não exige um segundo processo de exportação.

## Atualização: respostas conversacionais e perguntas sobre plantio

As contagens de ações passaram a trazer informações adicionais úteis (como municípios e temas), com variações de linguagem. Para perguntas sobre **quantas mudas ou árvores foram plantadas**, o chatbot consulta as **descrições das ações**, somando apenas quantidades expressamente associadas ao plantio executado e explicando quando o valor é parcial. As perguntas sobre temas mais frequentes agora utilizam todos os registros correspondentes.

Consulte `ATUALIZACAO_CONVERSA_E_DESCRICOES.md` para detalhes, limitações e perguntas de teste. A interface e as sugestões iniciais foram preservadas.

## 1. Como os dados chegam ao chatbot

```
Google Sheets → Heroku da sincronização → Cloudflare Pages (JSONs)
                                         ↓
                                Chatbot Flask + Groq
```

O backend acessa o arquivo:

- `https://nucas-dados.pages.dev/manifest.json`

E baixa somente as partes referenciadas pelo manifesto, pertencentes a `acoes_nuca`, `detalhes_nucas` e `detalhes_adolescentes`.

**A Cloudflare não precisa de nenhuma credencial de API para leitura pública.** O servidor consulta o manifesto a cada 10 minutos por padrão, mas só baixa as tabelas novamente quando o `snapshot_id` mudar. Ao ocorrer erro numa publicação, a última versão completa permanece em memória.

Os campos de ações são interpretados conforme a exportação atual: `status`, `uf`, `municipio`, `tema`, `descricao`, `ano_acao`, `publico`, `adoles_parcipantes`, `link_acao`. `publico` é a estimativa declarada de pessoas alcançadas pela ação, não pessoas únicas.

- Para pesquisa e contagens de ações, entram **Aprovado** e **Em validação/Aprovado**; não entra **Em validação**.
- Os dados de gênero e raça são agregados por município. O chatbot pode somar campos específicos, com as ressalvas dos registros publicados.
- O código ignora linhas de cabeçalho acidentalmente incluídas entre os dados (`UF` / `Município`).
- O chatbot **não publica** os dados; apenas lê o CDN. Continue publicando pelo Heroku de sincronização existente.

## 2. Configuração no Heroku

1. Substitua os arquivos do repositório do **chatbot** pelos do ZIP.
2. Faça commit/push e aguarde o deploy no Heroku deste chatbot.
3. No **Heroku → Settings → Config Vars**, configure no mínimo:

| Variável | Valor |
|---|---|
| `GROQ_API_KEY` | Chave secreta da sua conta Groq (não coloque no GitHub) |
| `AI_PROVIDER` | `groq` |
| `CLOUDFLARE_PAGES_URL` | `https://nucas-dados.pages.dev` |
| `GROQ_MODEL` | `openai/gpt-oss-20b` (ou modelo disponível na sua conta Groq) |

`CLOUDFLARE_PAGES_URL` já possui esse valor como **padrão no código**, mas configurá-lo no Heroku facilita futuras mudanças. As demais opções estão no `.env.example`.

4. Certifique-se de que o app usa o `Procfile` incluído para servir Flask com Gunicorn.
5. Abra as rotas abaixo:

- `/` — chatbot simplificado.
- `/api/data/status` — **teste real** de acesso ao manifesto e aos 3 conjuntos de dados.
- `/health` — informações de configuração (não prova que a Groq respondeu).

`/api/data/status` deve devolver `status: ok`, o identificador `snapshot_id` e as contagens. A contagem de `acoes_nuca` **pode ser menor** que a do manifesto, pois o chatbot ignora ações apenas `Em validação`.

**Não altere o app Heroku que envia dados do Google Sheets ao Supabase/Cloudflare**: ele continua independente e não precisa da chave Groq.

## 3. Teste local

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edite .env e coloque somente sua GROQ_API_KEY local
python scripts/verificar_dados.py
python app.py
```

Acesse `http://localhost:5000` e teste perguntas como:

- “Quantas ações foram realizadas em Pernambuco em 2026?”
- “Quais ações de meio ambiente ocorreram em Alagoas?”
- “Quantas pessoas foram alcançadas pelas ações em PE?”
- “Qual o perfil de gênero dos integrantes dos NUCAs?”
- “Quantos adolescentes indígenas estão registrados em Pernambuco?”

Uma pergunta sobre gênero ou raça que exige somas é respondida diretamente pelo servidor. Para perguntas descritivas sobre ações, o chatbot seleciona evidências do CDN e a Groq prepara o texto. A geração por IA depende da chave e da disponibilidade da Groq.

## 4. O que mudou em relação à versão enviada

- **`nuca_data.py`**: novo `CloudflarePagesStore` que baixa manifesto e partes das três tabelas; suporte aos nomes reais dos campos e à UF como `Pernambuco (PE)`.
- **`app.py`**: CDN como fonte padrão; endpoint `/api/data/status`; consultas sobre perfil por gênero/raça usando dados agregados.
- **`templates/index.html` + `static/css/style.css`**: retomada da barra lateral, avatar e cartões da versão anterior, mantendo a conversa em destaque e quatro perguntas apenas na abertura.
- **`static/js/chat.js`**: sem sugestões posteriores à primeira mensagem; formatação de tabelas, títulos e listas; mantém PT/EN, streaming, cópia, referências reais e nova conversa.
- **`scripts/verificar_dados.py`**: teste rápido do CDN sem precisar da chave Groq.

O frontend continua chamando apenas `POST /api/chat/stream` para conversar: **o navegador não precisa consultar o Supabase nem a Cloudflare diretamente**. Os arquivos JSON são carregados pelo servidor Python.

## 5. Segurança e observações

- Não inclua `GROQ_API_KEY`, tokens do Cloudflare, `service_role` ou outras chaves privadas no GitHub.
- A Cloudflare serve arquivos públicos. Antes de gerar uma resposta, o código usa apenas as ações com status publicável, mas as descrições são encaminhadas como evidências para a Groq. Revise conteúdo livre com dados pessoais.
- O cache de dados é por processo Gunicorn; se houver vários processos, cada um pode manter sua própria cópia dos JSONs.
- O endpoint `/api/data/status` é uma validação real do CDN; `/health` sozinho não confirma conectividade externa.
- A busca textual é lexical, não uma busca semântica indexada; resultados específicos devem ser conferidos nas fontes quando disponíveis.
- Caso queira usar um JSON único legado em vez do Cloudflare, defina `DATA_SOURCE_MODE=legacy` e configure `SNAPSHOT_URL` ou `SNAPSHOT_PATH`.
- Sem internet ou credenciais reais, os testes locais confirmam funcionamento do carregador com respostas simuladas, mas não autenticam na Groq nem verificam a versão de produção ao vivo.

## 6. Comandos de teste

```bash
python -m pytest -q tests/
python -m compileall -q app.py llm.py nuca_data.py scripts/verificar_dados.py
node --check static/js/chat.js
```

Caso `/api/data/status` indique erro 404 ou que o manifesto não é JSON, confira se o Cloudflare Pages já publicou `manifest.json` e se o `CLOUDFLARE_PAGES_URL` aponta para o domínio `.pages.dev`, sem o sufixo `/manifest.json`.

## Atualização: melhorias de linguagem e continuidade

Veja `NOVIDADES_E_TESTES.md` para as alterações de interpretação, os exemplos de perguntas e os testes.

## Atualização: contexto da conversa e rankings

Consulte [`CORRECOES_CONTEXTO_E_RANKINGS.md`](CORRECOES_CONTEXTO_E_RANKINGS.md) para a nova lógica de confirmação de perguntas ambíguas, herança seletiva de filtros e rankings por município/UF.
