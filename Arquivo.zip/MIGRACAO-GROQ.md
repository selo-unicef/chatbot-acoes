# Passos rápidos: trocar o chatbot para Groq

1. Envie os arquivos deste ZIP para o repositório do chatbot e faça o deploy no Heroku.
2. Crie uma chave em https://console.groq.com/keys
3. Em **Heroku → Settings → Config Vars**, configure:

   | Variável | Valor |
   | --- | --- |
   | `AI_PROVIDER` | `groq` |
   | `GROQ_API_KEY` | sua chave `gsk_...` |
   | `GROQ_MODEL` | `openai/gpt-oss-20b` |
   | `GROQ_REASONING_EFFORT` | `low` |
   | `MAX_OUTPUT_TOKENS` | `1200` |
   | `SNAPSHOT_URL` | URL HTTPS do JSON das ações, se já existir |

4. Confira `https://SEU-APP.herokuapp.com/health` e teste uma pergunta na interface.
5. Se ainda não tiver snapshot, você pode TEMPORARIAMENTE adicionar `OPENAI_API_KEY` e `OPENAI_VECTOR_STORE_ID` para recuperar evidências do banco vetorial antigo (a resposta continua sendo gerada na Groq). Para eliminar a dependência da OpenAI, configure o snapshot e remova essas duas variáveis.

**O nome `openai/gpt-oss-20b` é o ID de um modelo servido na Groq; não usa API da OpenAI.**

Os arquivos `templates/`, `static/`, `nuca_data.py`, `Procfile` e a exportação do Supabase foram preservados. A migração alterou essencialmente `llm.py`, `app.py`, `requirements.txt`, `.env.example` e a documentação.

Em caso de erro de chave ou cota, consulte o painel da Groq. Sem credenciais reais não é possível confirmar que a aplicação já esteja funcionando na sua conta.
