import logging
import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from openai import OpenAI


# ============================================================
# VARIÁVEIS DE AMBIENTE
# ============================================================

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

load_dotenv(ENV_PATH)


# ============================================================
# CONFIGURAÇÃO
# ============================================================

app = Flask(__name__)

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger(__name__)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_VECTOR_STORE_ID = os.getenv("OPENAI_VECTOR_STORE_ID")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5-mini")

MAX_SEARCH_RESULTS = int(
    os.getenv("MAX_SEARCH_RESULTS", "5")
)

MIN_SEARCH_SCORE = float(
    os.getenv("MIN_SEARCH_SCORE", "0.20")
)

MAX_HISTORY_MESSAGES = int(
    os.getenv("MAX_HISTORY_MESSAGES", "4")
)

MAX_CONTEXT_CHARS = int(
    os.getenv("MAX_CONTEXT_CHARS", "12000")
)

client = (
    OpenAI(api_key=OPENAI_API_KEY)
    if OPENAI_API_KEY
    else None
)


# ============================================================
# TEXTOS E INSTRUÇÕES
# ============================================================

TEXTS = {
    "pt": {
        "not_found": (
            "Não encontrei essa informação nas ações cadastradas. "
            "Tente perguntar de outra forma ou informar um município, "
            "estado ou tema."
        ),
        "invalid": "Digite uma pergunta para continuar.",
        "error": (
            "Não consegui consultar as ações agora. "
            "Tente novamente em instantes."
        ),
        "system": """
Você é o assistente virtual das Ações dos NUCAs.

Sua função é conversar com o usuário de forma natural, simples e acolhedora,
usando somente as informações presentes no contexto fornecido.

REGRAS SOBRE OS DADOS

- Responda exclusivamente com base no contexto recuperado.
- Não use conhecimentos externos.
- Não invente informações.
- Não complete dados ausentes com suposições.
- Não altere números, datas, nomes, municípios ou estados.
- Quando o contexto não for suficiente, diga isso de forma breve e natural.
- Não tente calcular o total de toda a base usando apenas alguns registros.
- Não mencione arquivos, vetores, embeddings, contexto recuperado ou
  ferramentas internas.

ESTILO DA CONVERSA

- Escreva em português do Brasil.
- Responda como em uma conversa, não como em um relatório.
- Comece diretamente pela resposta.
- Prefira frases curtas e naturais.
- Normalmente responda em um ou dois parágrafos curtos.
- Use listas apenas quando elas realmente ajudarem a leitura.
- Não repita a pergunta do usuário.
- Não use títulos como "Resposta", "Resultado", "Conclusão" ou "Observação".
- Não escreva frases como "Com base no contexto fornecido".
- Não explique limitações técnicas do sistema.
- Evite formalidade excessiva.
- Evite respostas longas.
- Quando houver muitos resultados, faça uma síntese e apresente apenas
  alguns exemplos mais relevantes.
- Quando o usuário pedir detalhes, aí sim ofereça uma resposta mais completa.

FONTES

- Não coloque uma lista extensa de IDs no corpo da resposta.
- Quando for útil identificar registros específicos, coloque ao final apenas:
  "Ações consultadas: ID 123, ID 456."
- Não mostre IDs quando eles não ajudarem o usuário.

EXEMPLOS DE TOM

Pergunta:
"Quais ações trataram de meio ambiente?"

Resposta adequada:
"Foram encontradas ações de plantio de mudas, limpeza de espaços públicos e
atividades de educação ambiental. Em alguns municípios, os adolescentes
também participaram de campanhas de conscientização sobre resíduos e
preservação."

Pergunta:
"Teve alguma ação em Maceió?"

Resposta adequada:
"Sim. Encontrei ações cadastradas em Maceió. Entre elas estão atividades
voltadas à participação de adolescentes e à mobilização comunitária."

Pergunta sem resposta suficiente:

Resposta adequada:
"Não encontrei essa informação nas ações cadastradas. Você pode tentar
informar o município, o estado ou o tema da atividade."
""".strip(),
    },

    "en": {
        "not_found": (
            "I could not find that information in the registered actions. "
            "Try mentioning a city, state, or topic."
        ),
        "invalid": "Type a question to continue.",
        "error": (
            "I could not search the actions right now. "
            "Please try again shortly."
        ),
        "system": """
You are the virtual assistant for NUCA Actions.

Talk to the user naturally, clearly, and concisely, using only the
information supplied in the retrieved context.

DATA RULES

- Answer exclusively from the supplied context.
- Do not use external knowledge.
- Do not invent or assume missing information.
- Preserve numbers, dates, names, cities, and states exactly.
- When the context is insufficient, say so briefly and naturally.
- Do not calculate totals for the entire database from a few retrieved items.
- Do not mention files, vectors, embeddings, retrieved context, or
  internal tools.

CONVERSATIONAL STYLE

- Answer in English.
- Start directly with the answer.
- Prefer short, natural sentences.
- Usually answer in one or two short paragraphs.
- Use lists only when they clearly improve readability.
- Do not repeat the user's question.
- Do not use headings such as "Answer", "Result", or "Conclusion".
- Avoid technical explanations and excessive formality.
- When there are many results, summarize them and mention only a few
  relevant examples.
- Give more detail only when the user explicitly asks for it.

SOURCES

- Do not include a long list of action IDs.
- Mention IDs only when they help identify specific records.
""".strip(),
    },
}


# ============================================================
# FUNÇÕES AUXILIARES
# ============================================================

def normalize_language(value: Any) -> str:
    return "en" if str(value).lower().startswith("en") else "pt"


def extract_result_text(result: Any) -> str:
    parts: list[str] = []

    for item in getattr(result, "content", []) or []:
        text = getattr(item, "text", None)

        if text:
            parts.append(str(text))

    return "\n".join(parts).strip()


def search_database(
    question: str,
) -> list[dict[str, Any]]:
    if not client or not OPENAI_VECTOR_STORE_ID:
        raise RuntimeError(
            "OPENAI_API_KEY ou OPENAI_VECTOR_STORE_ID "
            "não configurado."
        )

    search = client.vector_stores.search(
        vector_store_id=OPENAI_VECTOR_STORE_ID,
        query=question,
        max_num_results=MAX_SEARCH_RESULTS,
    )

    results: list[dict[str, Any]] = []

    for item in search.data:
        score = float(
            getattr(item, "score", 0) or 0
        )

        text = extract_result_text(item)

        if not text:
            continue

        if score < MIN_SEARCH_SCORE:
            continue

        results.append(
            {
                "file_id": getattr(
                    item,
                    "file_id",
                    "",
                ),
                "filename": getattr(
                    item,
                    "filename",
                    "",
                ),
                "score": score,
                "text": text,
            }
        )

    return results


def build_context(
    results: list[dict[str, Any]],
) -> str:
    blocks: list[str] = []
    total_chars = 0

    for index, result in enumerate(
        results,
        start=1,
    ):
        text = result["text"].strip()

        block = (
            f"REGISTRO OU TRECHO {index}\n"
            f"{text}"
        )

        if total_chars + len(block) > MAX_CONTEXT_CHARS:
            remaining = MAX_CONTEXT_CHARS - total_chars

            if remaining > 300:
                blocks.append(block[:remaining])

            break

        blocks.append(block)
        total_chars += len(block)

    return "\n\n---\n\n".join(blocks)


def clean_history(
    history: Any,
) -> list[dict[str, str]]:
    if not isinstance(history, list):
        return []

    cleaned: list[dict[str, str]] = []

    for item in history[-MAX_HISTORY_MESSAGES:]:
        if not isinstance(item, dict):
            continue

        role = item.get("role")
        content = str(
            item.get("content", "")
        ).strip()

        if role not in {
            "user",
            "assistant",
        }:
            continue

        if not content:
            continue

        cleaned.append(
            {
                "role": role,
                "content": content[:2000],
            }
        )

    return cleaned


def build_messages(
    question: str,
    context: str,
    history: list[dict[str, str]],
) -> list[dict[str, str]]:
    messages = history.copy()

    messages.append(
        {
            "role": "user",
            "content": (
                "Use os dados abaixo apenas como fonte para "
                "responder à pergunta.\n\n"
                f"DADOS DISPONÍVEIS:\n{context}\n\n"
                f"PERGUNTA ATUAL:\n{question}\n\n"
                "Responda de forma natural, curta e conversacional."
            ),
        }
    )

    return messages


# ============================================================
# ROTAS
# ============================================================

@app.get("/")
def index():
    return render_template("index.html")


@app.get("/health")
def health():
    configured = bool(
        client and OPENAI_VECTOR_STORE_ID
    )

    return jsonify(
        {
            "status": (
                "ok"
                if configured
                else "configuration_required"
            ),
            "openai_configured": configured,
        }
    ), 200 if configured else 503


@app.post("/api/chat")
def chat():
    payload = request.get_json(
        silent=True
    ) or {}

    language = normalize_language(
        payload.get("language")
    )

    texts = TEXTS[language]

    question = str(
        payload.get("message", "")
    ).strip()

    history = clean_history(
        payload.get("history")
    )

    if not question:
        return jsonify(
            {"error": texts["invalid"]}
        ), 400

    if len(question) > 1500:
        return jsonify(
            {"error": texts["invalid"]}
        ), 400

    try:
        results = search_database(question)

        if not results:
            return jsonify(
                {
                    "answer": texts["not_found"],
                    "sources": [],
                }
            )

        context = build_context(results)

        messages = build_messages(
            question=question,
            context=context,
            history=history,
        )

        response = client.responses.create(
            model=OPENAI_MODEL,
            instructions=texts["system"],
            input=messages,
            max_output_tokens=350,
            store=False,
        )

        answer = (
            response.output_text or ""
        ).strip()

        if not answer:
            answer = texts["not_found"]

        sources = [
            {
                "filename": result["filename"],
                "score": round(
                    result["score"],
                    4,
                ),
            }
            for result in results
        ]

        return jsonify(
            {
                "answer": answer,
                "sources": sources,
                "response_id": response.id,
            }
        )

    except Exception:
        logger.exception(
            "Erro ao responder pergunta"
        )

        return jsonify(
            {"error": texts["error"]}
        ), 500


if __name__ == "__main__":
    port = int(
        os.getenv("PORT", "5000")
    )

    app.run(
        host="0.0.0.0",
        port=port,
        debug=(
            os.getenv("FLASK_DEBUG") == "1"
        ),
    )