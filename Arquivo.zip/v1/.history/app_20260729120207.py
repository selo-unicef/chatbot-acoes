import logging
import os
from typing import Any

from flask import Flask, jsonify, render_template, request
from openai import OpenAI
from pathlib import Path
from dotenv import load_dotenv

app = Flask(__name__)

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger(__name__)

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"

load_dotenv(ENV_PATH)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_VECTOR_STORE_ID = os.getenv("OPENAI_VECTOR_STORE_ID")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5-mini")
MAX_SEARCH_RESULTS = int(os.getenv("MAX_SEARCH_RESULTS", "8"))
MIN_SEARCH_SCORE = float(os.getenv("MIN_SEARCH_SCORE", "0.20"))
MAX_HISTORY_MESSAGES = int(os.getenv("MAX_HISTORY_MESSAGES", "6"))

client = OpenAI(api_key=OPENAI_API_KEY) if OPENAI_API_KEY else None


TEXTS = {
    "pt": {
        "not_found": "Não encontrei essa informação na base de ações dos NUCAs.",
        "invalid": "Digite uma pergunta para continuar.",
        "error": "Não foi possível processar sua pergunta agora. Tente novamente em instantes.",
        "system": """
Você é o assistente oficial de consulta das Ações dos NUCAs.

Responda exclusivamente com base no CONTEXTO RECUPERADO fornecido.
Não use conhecimentos externos.
Não invente informações, números, datas, locais, resultados ou conclusões.
Quando a resposta não estiver claramente sustentada pelo contexto, responda:
"Não encontrei essa informação na base de ações dos NUCAs."

Regras:
- Responda em português do Brasil.
- Seja claro, acolhedor e objetivo.
- Quando houver várias ações, organize a resposta em uma lista curta.
- Cite os IDs das ações usadas no final da resposta.
- Não diga que consultou arquivos, embeddings, vetores ou uma ferramenta interna.
- Não some ou conte toda a base a partir de poucos resultados recuperados.
- Para perguntas que exigem total geral, deixe claro quando a busca não permite calcular o universo completo.
""".strip(),
    },
    "en": {
        "not_found": "I could not find that information in the NUCA actions database.",
        "invalid": "Type a question to continue.",
        "error": "Your question could not be processed right now. Please try again shortly.",
        "system": """
You are the official assistant for consulting NUCA Actions.

Answer exclusively from the supplied RETRIEVED CONTEXT.
Do not use external knowledge.
Do not invent information, numbers, dates, places, results, or conclusions.
When the answer is not clearly supported by the context, reply:
"I could not find that information in the NUCA actions database."

Rules:
- Answer in English.
- Be clear, welcoming, and concise.
- When several actions are relevant, use a short list.
- Cite the action IDs used at the end.
- Do not mention files, embeddings, vectors, or internal tools.
- Do not calculate totals for the entire database from only a few retrieved results.
- For questions requiring a global total, clarify when the search cannot calculate the complete universe.
""".strip(),
    },
}


def normalize_language(value: Any) -> str:
    return "en" if str(value).lower().startswith("en") else "pt"


def extract_result_text(result: Any) -> str:
    parts: list[str] = []

    for item in getattr(result, "content", []) or []:
        text = getattr(item, "text", None)
        if text:
            parts.append(str(text))

    return "\n".join(parts).strip()


def search_database(question: str) -> list[dict[str, Any]]:
    if not client or not OPENAI_VECTOR_STORE_ID:
        raise RuntimeError(
            "OPENAI_API_KEY ou OPENAI_VECTOR_STORE_ID não configurado."
        )

    search = client.vector_stores.search(
        vector_store_id=OPENAI_VECTOR_STORE_ID,
        query=question,
        max_num_results=MAX_SEARCH_RESULTS,
    )

    results: list[dict[str, Any]] = []

    for item in search.data:
        score = float(getattr(item, "score", 0) or 0)
        text = extract_result_text(item)

        if not text or score < MIN_SEARCH_SCORE:
            continue

        results.append(
            {
                "file_id": getattr(item, "file_id", ""),
                "filename": getattr(item, "filename", ""),
                "score": score,
                "text": text,
            }
        )

    return results


def build_context(results: list[dict[str, Any]]) -> str:
    blocks = []

    for index, result in enumerate(results, start=1):
        blocks.append(
            f"""TRECHO {index}
Relevância: {result["score"]:.4f}
Conteúdo:
{result["text"]}"""
        )

    return "\n\n---\n\n".join(blocks)


def clean_history(history: Any) -> list[dict[str, str]]:
    if not isinstance(history, list):
        return []

    cleaned: list[dict[str, str]] = []

    for item in history[-MAX_HISTORY_MESSAGES:]:
        if not isinstance(item, dict):
            continue

        role = item.get("role")
        content = str(item.get("content", "")).strip()

        if role not in {"user", "assistant"} or not content:
            continue

        cleaned.append({"role": role, "content": content[:3000]})

    return cleaned


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/health")
def health():
    configured = bool(client and OPENAI_VECTOR_STORE_ID)

    return jsonify(
        {
            "status": "ok" if configured else "configuration_required",
            "openai_configured": configured,
        }
    ), 200 if configured else 503


@app.post("/api/chat")
def chat():
    payload = request.get_json(silent=True) or {}
    language = normalize_language(payload.get("language"))
    texts = TEXTS[language]
    question = str(payload.get("message", "")).strip()
    history = clean_history(payload.get("history"))

    if not question:
        return jsonify({"error": texts["invalid"]}), 400

    if len(question) > 1500:
        return jsonify({"error": texts["invalid"]}), 400

    try:
        results = search_database(question)

        if not results:
            return jsonify(
                {
                    "answer": texts["not_found"],
                    "sources": [],
                }
            )

        context = build_context(results)

        messages = history + [
            {
                "role": "user",
                "content": (
                    f"RETRIEVED CONTEXT:\n\n{context}\n\n"
                    f"USER QUESTION:\n{question}"
                ),
            }
        ]

        response = client.responses.create(
            model=OPENAI_MODEL,
            instructions=texts["system"],
            input=messages,
            store=False,
        )

        answer = (response.output_text or "").strip()

        if not answer:
            answer = texts["not_found"]

        sources = [
            {
                "filename": result["filename"],
                "score": round(result["score"], 4),
            }
            for result in results
        ]

        return jsonify(
            {
                "answer": answer,
                "sources": sources,
                "response_id": response.id,
            }
        )

    except Exception:
        logger.exception("Erro ao responder pergunta")
        return jsonify({"error": texts["error"]}), 500


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG") == "1")
