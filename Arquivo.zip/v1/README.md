# Chatbot NUCA — Flask + OpenAI Vector Store

Chatbot responsivo para consultar exclusivamente a base de Ações dos NUCAs
armazenada em um OpenAI Vector Store.

## Estrutura

```text
chatbot-nuca-flask/
├── app.py
├── requirements.txt
├── Procfile
├── runtime.txt
├── .env.example
├── templates/
│   └── index.html
└── static/
    ├── css/style.css
    ├── js/chat.js
    └── img/
        ├── logo-nuca.svg
        └── avatar-nuca.svg
```

## Recursos

- Flask no backend.
- HTML, CSS e JavaScript puros no frontend.
- Layout responsivo para celular e desktop.
- Português e inglês.
- Busca direta no OpenAI Vector Store antes da geração.
- Resposta instruída a usar somente os trechos recuperados.
- Limite mínimo de relevância configurável.
- Histórico curto de conversa.
- Endpoint `/health`.
- Configuração pronta para Heroku/Gunicorn.

## Configuração local

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Defina as variáveis:

```bash
export OPENAI_API_KEY="sua-chave"
export OPENAI_VECTOR_STORE_ID="vs_xxxxxxxxx"
export OPENAI_MODEL="gpt-5-mini"
```

Execute:

```bash
python app.py
```

Acesse:

```text
http://localhost:5000
```

## Configuração no Heroku

Crie o aplicativo e defina as variáveis:

```bash
heroku create nome-do-app

heroku config:set \
  OPENAI_API_KEY="sua-chave" \
  OPENAI_VECTOR_STORE_ID="vs_xxxxxxxxx" \
  OPENAI_MODEL="gpt-5-mini"
```

Publique:

```bash
git init
git add .
git commit -m "Cria chatbot NUCA"
heroku git:remote -a nome-do-app
git push heroku main
```

## Teste de saúde

```text
https://nome-do-app.herokuapp.com/health
```

Com as variáveis corretas, o retorno será:

```json
{
  "status": "ok",
  "openai_configured": true
}
```

## Variáveis opcionais

```text
MAX_SEARCH_RESULTS=8
MIN_SEARCH_SCORE=0.20
MAX_HISTORY_MESSAGES=6
LOG_LEVEL=INFO
```

### `MIN_SEARCH_SCORE`

Controla o nível mínimo de similaridade aceito. Comece com `0.20` e ajuste
depois de testar perguntas reais:

- aumente quando estiver trazendo ações pouco relacionadas;
- diminua quando perguntas válidas retornarem “não encontrei”.

## Observação sobre contagens

A busca vetorial recupera os trechos mais relevantes, mas não percorre
necessariamente todos os registros. Portanto, totais gerais, somas e rankings
completos devem ser calculados em uma base estruturada como Supabase/SQL.
