const translations = {
  pt: {
    welcomeTitle: "Como posso te ajudar?",
    welcomeText: "Você pode me fazer perguntas sobre as Ações dos NUCAs!",
    question1: "Quais projetos foram realizados?",
    question2: "Quantos adolescentes participaram das ações?",
    question3: "Quais são as principais ações dos NUCAs?",
    question4: "Quais ações ambientais foram realizadas?",
    placeholder: "Digite sua pergunta...",
    inputLabel: "Digite sua pergunta",
    sending: "Consultando a base...",
    genericError: "Não foi possível processar sua pergunta agora."
  },
  en: {
    welcomeTitle: "How can I help you?",
    welcomeText: "You can ask me questions about NUCA Actions!",
    question1: "Which projects were carried out?",
    question2: "How many adolescents took part in the actions?",
    question3: "What are the main NUCA actions?",
    question4: "Which environmental actions were carried out?",
    placeholder: "Type your question...",
    inputLabel: "Type your question",
    sending: "Searching the database...",
    genericError: "Your question could not be processed right now."
  }
};

const state = {
  language: "pt",
  loading: false,
  history: []
};

const elements = {
  form: document.querySelector("#chatForm"),
  input: document.querySelector("#messageInput"),
  sendButton: document.querySelector("#sendButton"),
  messages: document.querySelector("#messages"),
  conversation: document.querySelector("#conversation"),
  welcomePanel: document.querySelector("#welcomePanel"),
  languageButtons: [...document.querySelectorAll(".language-button")],
  suggestionButtons: [...document.querySelectorAll(".suggestion")]
};

function translatePage() {
  const dictionary = translations[state.language];

  document.documentElement.lang = state.language === "pt" ? "pt-BR" : "en";

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const key = element.dataset.i18n;
    if (dictionary[key]) element.textContent = dictionary[key];
  });

  document.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
    const key = element.dataset.i18nPlaceholder;
    if (dictionary[key]) element.placeholder = dictionary[key];
  });

  elements.languageButtons.forEach((button) => {
    const active = button.dataset.language === state.language;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
}

function setLanguage(language) {
  state.language = language === "en" ? "en" : "pt";
  translatePage();
}

function scrollToBottom() {
  requestAnimationFrame(() => {
    elements.conversation.scrollTop = elements.conversation.scrollHeight;
  });
}

function createMessage(role, content, temporary = false) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;
  if (temporary) wrapper.dataset.temporary = "true";

  if (role === "assistant") {
    const avatar = document.createElement("img");
    avatar.className = "mini-avatar";
    avatar.src = "/static/img/avatar-nuca.svg";
    avatar.alt = "";
    wrapper.appendChild(avatar);
  }

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";
  bubble.textContent = content;
  wrapper.appendChild(bubble);

  elements.messages.appendChild(wrapper);
  scrollToBottom();

  return wrapper;
}

function createTypingMessage() {
  const wrapper = document.createElement("div");
  wrapper.className = "message assistant";
  wrapper.dataset.temporary = "true";

  const avatar = document.createElement("img");
  avatar.className = "mini-avatar";
  avatar.src = "/static/img/avatar-nuca.svg";
  avatar.alt = "";

  const bubble = document.createElement("div");
  bubble.className = "message-bubble";

  const typing = document.createElement("span");
  typing.className = "typing";
  typing.setAttribute("aria-label", translations[state.language].sending);
  typing.innerHTML = "<span></span><span></span><span></span>";

  bubble.appendChild(typing);
  wrapper.append(avatar, bubble);
  elements.messages.appendChild(wrapper);
  scrollToBottom();

  return wrapper;
}

function setLoading(loading) {
  state.loading = loading;
  elements.input.disabled = loading;
  elements.sendButton.disabled = loading;
}

function resizeInput() {
  elements.input.style.height = "auto";
  elements.input.style.height = `${Math.min(elements.input.scrollHeight, 160)}px`;
}

async function sendQuestion(rawQuestion) {
  const question = rawQuestion.trim();

  if (!question || state.loading) return;

  elements.welcomePanel.hidden = true;
  createMessage("user", question);
  state.history.push({ role: "user", content: question });

  elements.input.value = "";
  resizeInput();
  setLoading(true);

  const typingMessage = createTypingMessage();

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: question,
        language: state.language,
        history: state.history.slice(-6)
      })
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.error || translations[state.language].genericError);
    }

    typingMessage.remove();
    createMessage("assistant", data.answer);
    state.history.push({ role: "assistant", content: data.answer });
  } catch (error) {
    typingMessage.remove();
    createMessage(
      "assistant",
      error.message || translations[state.language].genericError
    );
  } finally {
    setLoading(false);
    elements.input.focus();
  }
}

elements.form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendQuestion(elements.input.value);
});

elements.input.addEventListener("input", resizeInput);

elements.input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendQuestion(elements.input.value);
  }
});

elements.languageButtons.forEach((button) => {
  button.addEventListener("click", () => {
    setLanguage(button.dataset.language);
  });
});

elements.suggestionButtons.forEach((button) => {
  button.addEventListener("click", () => {
    const key = button.dataset.questionKey;
    sendQuestion(translations[state.language][key]);
  });
});

translatePage();
resizeInput();
