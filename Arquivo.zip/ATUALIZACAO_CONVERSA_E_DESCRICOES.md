# Atualização: conversa mais natural e números presentes nas descrições

Esta versão mantém o layout, os quatro cartões **apenas na tela inicial**, o chat com Groq, a leitura das três tabelas do Cloudflare Pages e as regras de status anteriores. **Não modifica HTML, CSS ou JavaScript do navegador.**

## Melhorias

1. **Respostas numéricas menos secas:** além do total de ações, a resposta pode informar quantos municípios aparecem no recorte e qual tema predomina. A frase de abertura varia conforme o andamento da conversa; os números são sempre calculados pelo Python.
2. **Perguntas sobre resultados de plantio:** o chatbot reconhece perguntas como “Quantas mudas foram plantadas?” e “Quantas árvores foram plantadas?”. Para essas questões, busca as quantidades expressamente mencionadas nas descrições das ações. Trata ações “Aprovado” e “Em validação/Aprovado” como elegíveis, mantendo o recorte geográfico ou temático da conversa.
3. **Quantidades parciais, sem inventar números:** ignora menções a mudas doadas ou distribuídas sem evidência de plantio, objetivos futuros, aproximações, números de participantes e repetições do mesmo valor em uma mesma descrição. Nem todo relato contém informação suficiente; a soma é apresentada como **parcial** e não como total oficial de mudas distintas. O extrator é conservador e pode deixar de identificar certas redações.
4. **Temas mais frequentes:** perguntas sobre principais temas de um município ou estado são calculadas em todos os registros do recorte, e não com uma amostra de seis ações.
5. **Perguntas não previstas:** permanecem disponíveis a busca nas descrições das atividades e a geração pela Groq. Sem contagem estruturada confiável, o chatbot não deve apresentar uma pequena amostra como total geral.

## Arquivos alterados

- `nuca_data.py`: respostas de contagem contextualizadas, indicador de mudas/árvores e temas frequentes.
- `descricao_quantidades.py`: novo extrator conservador de quantidades informadas em relatos de plantio.
- `app.py`: aplica a nova consulta antes de contar ações; preserva os filtros nas perguntas de continuação.
- `llm.py`: instruções para respostas mais naturais e cuidadosas com quantidades em textos livres.
- `tests/test_quantidades_descricao.py`: testes de segurança e regressão do extrator.

**Nenhuma alteração em `templates/index.html`, `static/css/style.css` ou `static/js/chat.js`.**

## Exemplos para testar

1. “Quantas ações foram registradas no Brasil?”
2. “E quantas foram realizadas em Alagoas?”
3. “Quantas ações teve Penedo, em Alagoas?”
4. “Quais os principais temas das ações em Penedo?”
5. “Quantas ações foram voltadas a plantio de mudas?”
6. “E quantas mudas foram plantadas?”
7. “Pode detalhar?”
8. “Quantas árvores foram plantadas em Pernambuco?”

**Atenção:** o total de ações sobre plantio e o número de mudas plantadas são medidas diferentes. Uma ação pode falar sobre plantio sem informar quantas mudas foram utilizadas. Não confie em um total de mudas sem verificar as descrições e a cobertura dos relatos; o sistema mostra a quantidade de ações que sustentam a soma.

## Executar no Mac

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Adicione GROQ_API_KEY ao .env sem enviar o arquivo ao GitHub.
python app.py
```

Abra `http://localhost:5000`. Para verificar a conexão com os dados, execute `python scripts/verificar_dados.py` ou abra `/api/data/status`.

## Testes automatizados

```bash
python -m pytest -q
```

Os testes de extração usam dados fictícios e não substituem validação dos registros de produção. É recomendável conferir manualmente relatos que mencionam muitas quantidades ou misturam plantio, doação e distribuição.
