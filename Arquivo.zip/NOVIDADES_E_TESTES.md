# Assistente NUCA — melhorias de interpretação e interface

## Mudanças nesta versão

- Voltaram a barra lateral com identidade Selo UNICEF, a ilustração de abertura, o avatar nas respostas e os quatro cartões **apenas na tela inicial**.
- Removidas as sugestões automáticas depois de cada resposta.
- Nenhum número agregado usa endereço técnico como fonte visível. Links só aparecem para publicações das próprias atividades, quando disponíveis.
- Retirados das respostas os termos “snapshot”, “manifesto”, “Cloudflare”, “JSON” e explicações técnicas da infraestrutura.
- Contagens de atividades são calculadas sobre todos os registros elegíveis; uma amostra de três exemplos ou seis referências nunca é descrita como total.
- Temas/categorias são comparados com os valores reais do campo `tema`, incluindo **Empoderamento de meninas**. Não se confunde mais o tema com o campo `feminino`.
- Para assuntos não pertencentes a uma categoria, busca termos nas descrições e nos temas. “Plantio” considera termos como `plantio`, `mudas` e `reflorestamento` (pode subestimar ações descritas com outras palavras). Nunca retorna o total geral só por não reconhecer o tema.
- Melhor interpretação de continuidades, com atualização de estado, tema e ano entre perguntas de uma mesma conversa.
- O retorno “Pode detalhar?” apresenta o total real, a quantidade de municípios, os principais temas e alguns exemplos, sem confundir amostra com universo.
- Respostas com títulos, tabelas e listas agora têm melhor formatação visual.
- Continuam funcionando os JSONs públicos, os três conjuntos de dados, os filtros, a Groq, o streaming, o seletor de idioma e o botão de nova conversa.

## Substituir no projeto

Extraia este ZIP sobre a pasta do chatbot, substituindo os arquivos de mesmo nome. **Não** envie seu `.env` nem chaves secretas para o GitHub. O projeto não precisa de mudanças no painel de adolescentes, no painel de ações, no Passaporte ou no processo Heroku que envia dados para a Cloudflare.

## Teste no Mac

```bash
cd /caminho/para/a/pasta/do/chatbot
source .venv/bin/activate
pip install -r requirements.txt
python scripts/verificar_dados.py
python app.py
```

Abra `http://localhost:5000`. Caso não exista `.venv`, crie com `python3 -m venv .venv` e ative; configure `.env` a partir de `.env.example` e sua `GROQ_API_KEY`.

Teste as perguntas abaixo, na mesma conversa:

1. `Quantas ações foram realizadas em Pernambuco?`
2. `Pode detalhar?`
3. `E em Alagoas?`
4. `Pode detalhar?`

Depois clique em **Nova conversa** e teste:

- `Quantas ações de plantio foram feitas no Brasil?`
- `Qual o total de ações de Alagoas na categoria de Empoderamento de meninas?`
- `Quantas ações na categoria Saúde integral e integrada de adolescentes foram realizadas em Pernambuco?`

Os números reais mudam conforme as publicações das ações. Não use os valores dos testes automatizados como indicadores reais: os testes usam dados fictícios.

## Testes automatizados

```bash
python -m pytest -q tests/
python -m compileall -q app.py llm.py nuca_data.py
node --check static/js/chat.js
```

**Nota sobre precisão:** a contagem de categorias é exata para os registros elegíveis existentes no arquivo do chatbot. Pesquisas textuais abertas (por exemplo, `plantio`) são correspondências de palavras e sinônimos, não uma classificação semântica exaustiva. O reconhecimento por IA em respostas descritivas também pode falhar; confira exemplos e dados originais quando necessário.
