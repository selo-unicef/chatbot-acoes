# Chatbot NUCA — implantação rápida

## O que este ZIP modifica

- Usa `https://nucas-dados.pages.dev/manifest.json` e os JSONs publicados pelo Heroku que já sincroniza os dados.
- Consulta ações, gênero e raça no backend Python; **não faz consultas ao Supabase**.
- Tem layout simplificado de chat, sem a antiga barra lateral.

## Publicar no seu repositório do chatbot

1. Faça backup do repositório atual do chatbot.
2. Copie **todo o conteúdo do ZIP para a raiz desse repositório**, mantendo as pastas `static/` e `templates/`.
3. No Heroku desse chatbot, confira que `GROQ_API_KEY` está configurado nas Config Vars. **Não inclua a chave no código.**
4. A variável `CLOUDFLARE_PAGES_URL` já tem o padrão `https://nucas-dados.pages.dev`, mas pode ser configurada no Heroku com esse valor.
5. Faça commit, push e deploy. Os dados são consultados diretamente da Cloudflare, sem novo agendamento.
6. Abra `https://SEU-CHATBOT.herokuapp.com/api/data/status` e confira `status: ok` e as três tabelas.
7. Abra a home `/` e faça uma pergunta.

### Comandos sugeridos

```bash
git add .
git commit -m "Simplifica chatbot e integra dados Cloudflare Pages"
git push origin main
```

### Se aparecer algum erro

- `/api/data/status` retorna 503: confira que `/manifest.json` existe e que os arquivos `parte-001.json` estão acessíveis na Cloudflare.
- A tela carrega, mas a resposta da IA falha: verifique `GROQ_API_KEY`, modelo Groq e logs do Heroku.
- Aparece uma contagem de ações menor do que no manifesto: isso é esperado quando há ações somente `Em validação`, pois essas não entram nas respostas.

**Não altere o Heroku da sincronização (`send-api-unicef`) nem o painel principal.** A mudança é somente neste projeto do chatbot.

Para detalhes, veja `README.md`.

## Novidade — respostas mais completas

Esta versão também responde perguntas como “E quantas mudas foram plantadas?” lendo quantidades explícitas nas descrições, com aviso quando o resultado é parcial. As respostas de totais foram ampliadas e variadas, sem mudar o layout nem acrescentar sugestões automáticas. Consulte `ATUALIZACAO_CONVERSA_E_DESCRICOES.md`.
