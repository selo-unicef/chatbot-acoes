"""Chatbot NUCAs v2 — Flask, snapshot/CDN, RAG, respostas em streaming."""
from __future__ import annotations

import json
import logging
import os
import re
import threading
import time
from collections import OrderedDict, defaultdict, deque
from pathlib import Path
from typing import Any

from dotenv import load_dotenv
from flask import Flask, Response, jsonify, render_template, request, stream_with_context

from llm import produce, search_vector
from nuca_data import (CloudflarePagesStore, SnapshotStore, compute_profile_stats, compute_stats,
                       compute_action_details, compute_text_quantities, compute_theme_breakdown, text_quantity_intent, is_details_request, is_followup_question, should_summarize_actions, conversation_context_question, clarification_request,
                       evidence, search_snapshot)

load_dotenv(Path(__file__).resolve().parent / '.env')
logging.basicConfig(level=os.getenv('LOG_LEVEL','INFO'), format='%(asctime)s | %(levelname)s | %(message)s')
logger = logging.getLogger('nuca')

app = Flask(__name__)
app.json.ensure_ascii = False
app.config['MAX_CONTENT_LENGTH'] = 32_768
app.config['JSON_SORT_KEYS'] = False

# Fonte padrão: os mesmos snapshots públicos utilizados pelo frontend NUCA.
# Para voltar a um JSON legado local, configure DATA_SOURCE_MODE=legacy.
if os.getenv('DATA_SOURCE_MODE', 'cloudflare').lower() == 'legacy':
    store = SnapshotStore(
        path=os.getenv('SNAPSHOT_PATH', ''),
        url=os.getenv('SNAPSHOT_URL', ''),
        ttl=int(os.getenv('SNAPSHOT_TTL_SECONDS', '7200')),
    )
else:
    store = CloudflarePagesStore(
        base_url=os.getenv('CLOUDFLARE_PAGES_URL', 'https://nucas-dados.pages.dev'),
        ttl=int(os.getenv('CLOUDFLARE_CACHE_SECONDS', '600')),
    )

# Cota básica por processo (em várias instâncias, utilizar rate limiting no proxy/CDN).
_rate_lock = threading.Lock()
_rate_hits = defaultdict(deque)
_cache_lock = threading.Lock()
_cache: OrderedDict = OrderedDict()


def t(language: str, pt: str, en: str) -> str:
    return en if language == 'en' else pt


def throttle() -> bool:
    if os.getenv('DISABLE_RATE_LIMIT','0') == '1':
        return False
    identifier = request.remote_addr or 'unknown'
    now = time.monotonic()
    cap = int(os.getenv('RATE_LIMIT_PER_MINUTE','20'))
    with _rate_lock:
        hits = _rate_hits[identifier]
        while hits and hits[0] < now - 60:
            hits.popleft()
        if len(hits) >= cap:
            return True
        hits.append(now)
        if len(_rate_hits) > 3000:
            for key in list(_rate_hits)[:500]:
                if not _rate_hits[key] or _rate_hits[key][-1] < now - 60:
                    del _rate_hits[key]
    return False


def clean_history(raw: Any, question: str) -> list[dict]:
    if not isinstance(raw, list):
        return []
    items = []
    for item in raw[-8:]:
        if not isinstance(item, dict):
            continue
        role, content = item.get('role'), item.get('content')
        if role in ('user','assistant') and isinstance(content, str) and content.strip():
            items.append({'role':role,'content':content.strip()[:1200]})
    # Evita duplicar a pergunta atual (bug do projeto anterior).
    if items and items[-1]['role'] == 'user' and items[-1]['content'] == question:
        items.pop()
    return items[-6:]


def valid_payload():
    raw = request.get_json(silent=True)
    if not isinstance(raw, dict):
        return None, ('Corpo JSON inválido.', 400)
    q = raw.get('message')
    if not isinstance(q, str) or not q.strip() or len(q) > 1600:
        return None, ('Digite uma pergunta de até 1.600 caracteres.', 400)
    q = q.strip()
    lang = 'en' if str(raw.get('language','pt')).lower().startswith('en') else 'pt'
    return {'question':q,'language':lang,'history':clean_history(raw.get('history'),q)}, None


def prepare(question: str, history: list[dict], language: str) -> dict:
    records = store.get()
    # Solicitar esclarecimento em vez de escolher entre métricas diferentes.
    clarify = clarification_request(question, history, language)
    if clarify:
        return {'direct':clarify, 'context':'', 'sources':[],
                'data_mode':'clarification', 'snapshot_count':len(records) if records is not None else None}
    previous = conversation_context_question(question, history, records or [])
    if records is not None:
        datasets = store.get_datasets() if hasattr(store, 'get_datasets') else None
        # Consultas a unidades físicas nas descrições vêm ANTES das contagens
        # de ações: "quantas mudas?" não pode herdar o indicador "quantas ações?".
        quantity_unit = text_quantity_intent(question)
        if not quantity_unit and is_followup_question(question) and not re.search(
                r'\b(?:acoes|atividades|pessoas|adolescentes|municipios|cidades)\b', question, re.I):
            # O contexto resolvido pode preservar mudas após vários seguimentos
            # ("quantas mudas?" -> "e em AL?" -> "pode detalhar?").
            quantity_unit = text_quantity_intent(previous)
        if quantity_unit:
            extracted = compute_text_quantities(
                records, question, previous, language, unit=quantity_unit,
                detailed=is_details_request(question))
            if extracted is not None:
                return {'direct':extracted, 'context':'', 'sources':[],
                        'data_mode':'data', 'snapshot_count':len(records)}
        is_detail = should_summarize_actions(question, previous)
        if is_detail:
            detail = compute_action_details(records, question, previous, language)
            if detail is not None:
                return {'direct':detail, 'context':'', 'sources':[],
                        'data_mode':'data', 'snapshot_count':len(records)}
        themes = compute_theme_breakdown(records, question, previous, language)
        if themes is not None:
            return {'direct':themes, 'context':'', 'sources':[],
                    'data_mode':'data', 'snapshot_count':len(records)}
        # Ações/categorias são consultadas antes dos dados de gênero e raça.
        profile = compute_profile_stats(datasets, question, previous, language) if datasets else None
        if profile is not None:
            return {'direct':profile, 'context':'', 'sources':[],
                    'data_mode':'data', 'snapshot_count':len(records)}
        calculated = compute_stats(records, question, previous, language,
                                   style=sum(m['role'] == 'user' for m in history))
        if calculated is not None:
            return {'direct':calculated, 'context':'', 'sources':[],
                    'data_mode':'data', 'snapshot_count':len(records)}
        # Não permita ao modelo deduzir rankings, totais ou liderança a partir
        # das poucas evidências recuperadas para respostas descritivas.
        if re.search(r'\b(?:qual|quais|quem|onde)\b.*\b(?:mais acoes|mais atividades|maior numero|lidera|lideram)\b',
                     question, re.I):
            return {'direct':t(language,
                'Para comparar os locais, diga se você quer o município ou o estado com mais ações registradas.',
                'Please specify whether you want the municipality or the state with the most recorded activities.'),
                'context':'', 'sources':[], 'data_mode':'clarification', 'snapshot_count':len(records)}
        results = search_snapshot(records, question, previous, int(os.getenv('MAX_EVIDENCE','6')))
        context, refs = evidence(results)
        vector_enabled = (os.getenv('RETRIEVAL_MODE','auto') in ('hybrid','vector')
                          or (not results and os.getenv('RETRIEVAL_MODE','auto')=='auto'))
        if vector_enabled and os.getenv('OPENAI_VECTOR_STORE_ID'):
            vcontext, vrefs = search_vector(question + ('; pergunta anterior: '+ previous if previous else ''))
            if vcontext:
                offset = len(refs)
                if offset:
                    for num in range(len(vrefs),0,-1):
                        vcontext = re.sub(r'\['+str(num)+r'\]', '['+str(num+offset)+']',vcontext)
                for item in vrefs:
                    item['ref']+=offset
                context='\n\n'.join(filter(None,[context,vcontext]))
                refs+=vrefs
        # Nunca exibir URLs de infraestrutura. Referências só para ações com links próprios.
        for ref in refs:
            url = ref.get('url')
            if url and ('pages.dev' in url or '/manifest.json' in url):
                ref['url'] = None
        return {'direct':None, 'context':context, 'sources':refs,
                'data_mode':'data', 'snapshot_count':len(records)}
    if os.getenv('OPENAI_VECTOR_STORE_ID') and os.getenv('OPENAI_API_KEY'):
        context, refs = search_vector(question + ('; contexto anterior: '+previous if previous else ''))
        if re.search(r'\b(quant[oa]s?|total|ranking|somatorio|soma)\b', question, flags=re.I):
            answer = t(language,
                'Ainda não tenho dados suficientes para calcular esse total com segurança.',
                'I do not have enough data to calculate a reliable total.')
            return {'direct':answer,'context':'','sources':[], 'data_mode':'vector','snapshot_count':None}
        return {'direct':None,'context':context,'sources':refs,'data_mode':'vector','snapshot_count':None}
    return {'direct':t(language,
        'Não consegui acessar as informações dos NUCAs agora. Tente novamente em instantes.',
        'I could not access the NUCA information right now. Please try again shortly.'),
        'context':'','sources':[],'data_mode':'none','snapshot_count':None}


def sse(event: str, data: Any) -> str:
    return f'event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n'


def cache_get(key: str):
    if os.getenv('ENABLE_RESPONSE_CACHE','false').lower() != 'true':
        return None
    with _cache_lock:
        value = _cache.get(key)
        if value and value[0] > time.monotonic():
            _cache.move_to_end(key)
            return value[1]
        if value:
            del _cache[key]
    return None


def cache_set(key: str, answer: str):
    if os.getenv('ENABLE_RESPONSE_CACHE','false').lower() != 'true':
        return
    with _cache_lock:
        _cache[key] = (time.monotonic()+1800, answer)
        _cache.move_to_end(key)
        while len(_cache) > 150:
            _cache.popitem(last=False)


def answer_chunks(payload: dict, plan: dict):
    if plan['direct'] is not None:
        yield plan['direct']
        return
    provider = os.getenv('AI_PROVIDER','groq')
    cache_key = json.dumps((provider, os.getenv('GROQ_MODEL', 'openai/gpt-oss-20b'), payload['language'],payload['question'].lower(),store.version),ensure_ascii=False)
    if not payload['history']:
        cached = cache_get(cache_key)
        if cached is not None:
            yield cached
            return
    output = []
    for delta in produce(payload['language'], payload['question'],payload['history'], plan['context'],provider):
        output.append(delta)
        yield delta
    if not payload['history'] and output:
        cache_set(cache_key, ''.join(output))


@app.get('/')
def index():
    return render_template('index.html')


@app.get('/health')
def health():
    key_available = bool(os.getenv('GROQ_API_KEY')) and os.getenv('AI_PROVIDER', 'groq') == 'groq'
    has_dataset = store.configured() or bool(os.getenv('OPENAI_VECTOR_STORE_ID') and os.getenv('OPENAI_API_KEY'))
    return jsonify({'status': 'ok' if key_available and has_dataset else 'configuration_required',
                    'ai_provider':os.getenv('AI_PROVIDER','groq'),
                    'model':os.getenv('GROQ_MODEL','openai/gpt-oss-20b'),
                    'dataset': 'cloudflare' if isinstance(store, CloudflarePagesStore) else ('snapshot' if store.configured() else ('vector' if has_dataset else 'missing')),
                    'snapshot_loaded':len(store.records) if store.records is not None else None,
                    'snapshot_id': store.version or None,
                    'data_error': store.error or None}), (200 if key_available and has_dataset else 503)




@app.get('/api/data/status')
def data_status():
    datasets = store.get_datasets() if hasattr(store, 'get_datasets') else None
    if datasets is None and not hasattr(store, 'get_datasets'):
        records = store.get()
        datasets = {'acoes_nuca': records} if records is not None else None
    if datasets is None:
        return jsonify({'status':'unavailable','source':store.url,'message':store.error or 'A fonte ainda não foi carregada'}), 503
    return jsonify({
        'status':'ok', 'source':store.url,
        'snapshot_id':store.version or None,
        'updated_at':getattr(store, 'updated_at', '') or None,
        'records':{k:len(v) for k,v in datasets.items()},
        'note':'Ações elegíveis incluem Aprovado e Em validação/Aprovado; Em validação não entra nos resultados.'
    })

@app.post('/api/chat')
def chat_legacy():
    payload, error = valid_payload()
    if error:
        return jsonify({'error':error[0]}), error[1]
    if throttle():
        return jsonify({'error':'Limite temporário de mensagens atingido. Tente novamente em um minuto.'}), 429
    try:
        plan = prepare(payload['question'],payload['history'],payload['language'])
        answer = ''.join(answer_chunks(payload,plan))
        return jsonify({'answer':answer, 'sources':plan['sources'], 'data_mode':plan['data_mode']})
    except Exception:
        logger.exception('Falha em /api/chat')
        return jsonify({'error':'Não foi possível concluir a resposta. Confira a chave e os limites de uso da Groq e tente novamente.'}), 502


@app.post('/api/chat/stream')
def chat_stream():
    payload, error = valid_payload()
    if error:
        return jsonify({'error':error[0]}), error[1]
    if throttle():
        return jsonify({'error':'Limite temporário de mensagens atingido. Tente novamente em um minuto.'}), 429

    def generate():
        try:
            plan = prepare(payload['question'],payload['history'],payload['language'])
            yield sse('meta', {'sources':plan['sources'], 'data_mode':plan['data_mode']})
            count = 0
            for chunk in answer_chunks(payload,plan):
                count += len(chunk)
                yield sse('delta', {'text':chunk})
            if count == 0:
                yield sse('delta', {'text':t(payload['language'],
                    'Não consegui gerar uma resposta desta vez. Pode reformular a pergunta?',
                    'I could not generate an answer this time. Could you rephrase the question?')})
            yield sse('done', {'ok': True})
        except Exception:
            logger.exception('Falha ao transmitir resposta')
            yield sse('error', {'message':'Não foi possível responder no momento. Verifique se o modelo e a chave Groq estão disponíveis.'})

    return Response(stream_with_context(generate()),mimetype='text/event-stream',headers={
        'Cache-Control':'no-cache, no-store', 'X-Accel-Buffering':'no', 'X-Content-Type-Options':'nosniff',
    })


@app.after_request
def security_headers(resp):
    resp.headers['X-Content-Type-Options'] = 'nosniff'
    resp.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    resp.headers['X-Frame-Options'] = 'SAMEORIGIN'
    resp.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'"
    return resp

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')),debug=os.getenv('FLASK_DEBUG')=='1',threaded=True)
