# Chatbot NUCA — correções de contexto, indicadores e rankings

## O que mudou

O chatbot continua lendo as mesmas três tabelas públicas no Cloudflare Pages e mantém **os mesmos arquivos HTML, CSS e JavaScript de interface**.

As mudanças estão no Python (`app.py`, `nuca_data.py`) e em novos testes:

- **Perguntas independentes** não herdam assunto, unidade ou geografia da pergunta anterior.
- **Seguimentos contextuais** (“E em Alagoas?”, “Pode detalhar?”, “De exemplos no estado...”) recuperam apenas os filtros que fazem sentido. Quando uma nova UF é informada, um município anterior é descartado.
- **“Ações totais”** limpa filtros temáticos, incluindo “plantio”, e conta todas as ações elegíveis do recorte. O critério de elegibilidade permanece: `Aprovado` ou `Em validação/Aprovado`.
- **Perguntas ambíguas** como “Agora quero saber o total de Alagoas” geram uma pergunta curta de confirmação antes de apresentar um número. A resposta “ações” ou “mudas” é compreendida no contexto.
- **Temas com mais ações** são calculados sobre todos os registros elegíveis, não sobre exemplos da pesquisa textual.
- **Rankings** como “Qual município do país fez mais ações?” são calculados por município **e UF**, para não juntar homônimos de estados diferentes. Empates são informados.
- **Exemplos de ações** preservam a referência geográfica (“no estado”) e o tema indicado na pergunta atual.
- Mantida a orientação de não apresentar contagens e rankings a partir de seis exemplos recuperados pela busca semântica.

## Testar localmente

No terminal do projeto:

```bash
source .venv/bin/activate
python app.py
```

Acesse `http://127.0.0.1:5000` e reproduza esta sequência:

1. Quantas ações foram registradas no Brasil?
2. Quantas mudas de plantas foram plantadas nas ações?
3. E quantas ações totais foram feitas em Alagoas?  *(deve contar ações, não mudas)*
4. Certo, agora quero saber o total de Alagoas.  *(deve perguntar se você quer ações ou mudas)*
5. Ações.  *(deve responder sobre o total de ações em AL)*
6. Quais os temas com mais ações em Pernambuco?
7. Dê exemplos de algumas ações no estado sobre Prevenção às violências. *(deve restringir a PE)*
8. Qual município do país fez mais ações? *(deve calcular o ranking sobre todos os registros)*

## Testes automatizados

```bash
python -m pytest -q
```

A execução local do pacote de testes sintéticos passou (69 testes). No ambiente de criação do ZIP, o teste de integração Flask foi ignorado por falta da dependência instalada; execute-o em seu `.venv` com `pip install -r requirements.txt`.

## Publicar

Substitua apenas `app.py`, `nuca_data.py` e, se desejar, atualize também `tests/` e a documentação. O ZIP contém o projeto completo e pode substituir os arquivos de trabalho. Não publique o `.env` ou chaves da Groq em repositórios públicos.

## Limites

Os rankings e totais usam **todos os registros carregados**, mas a precisão depende do preenchimento dos campos e do critério de aprovação. Quantidades extraídas de descrições (como mudas) continuam sendo estimativas parciais fundamentadas em menções explícitas, nunca uma medição exaustiva.
